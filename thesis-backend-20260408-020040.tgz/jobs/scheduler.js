const cron = require('node-cron');
const { checkPermitExpiry } = require('./permitExpiryChecker');
const { processNotificationPushQueue } = require('./notificationPushDispatcher');

let lastPushSkipReason = null;

/**
 * Job Scheduler
 * Manages all scheduled background jobs
 */

function startScheduler() {
  console.log('[Scheduler] Starting background jobs...');

  // Try one pass on startup so queued notifications are flushed quickly.
  processNotificationPushQueue().then((result) => {
    if (result?.skipped && result.reason) {
      lastPushSkipReason = result.reason;
      console.warn(`[Scheduler] Initial push dispatch skipped: ${result.reason}`);
    }
  }).catch((err) => {
    console.error('[Scheduler] Initial push dispatch failed:', err);
  });

  // Run permit expiry checker daily at 2:00 AM
  cron.schedule('0 2 * * *', async () => {
    console.log('[Scheduler] Running permit expiry check...');
    try {
      await checkPermitExpiry();
    } catch (err) {
      console.error('[Scheduler] Permit expiry check failed:', err);
    }
  }, {
    timezone: 'Asia/Manila'
  });

  // Dispatch push notifications every minute.
  cron.schedule('* * * * *', async () => {
    try {
      const result = await processNotificationPushQueue();
      if (result?.skipped) {
        if (result.reason && result.reason !== lastPushSkipReason) {
          console.warn(`[Scheduler] Push dispatch skipped: ${result.reason}`);
        }
        lastPushSkipReason = result.reason || lastPushSkipReason;
        return;
      }

      lastPushSkipReason = null;
      if (result && !result.skipped && result.processed > 0) {
        console.log(
          `[Scheduler] Push dispatch: processed=${result.processed}, sent=${result.sent}, failed=${result.failed}, deactivated_tokens=${result.deactivated_tokens}`
        );
      }
    } catch (err) {
      console.error('[Scheduler] Push dispatch failed:', err);
    }
  }, {
    timezone: 'Asia/Manila'
  });

  console.log('[Scheduler] Permit expiry checker scheduled (daily at 2:00 AM PHT)');
  console.log('[Scheduler] Push dispatcher scheduled (every minute)');
}

module.exports = { startScheduler };
